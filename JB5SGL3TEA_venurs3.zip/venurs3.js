/*
let idforADDcart = document.getElementById("idforADDcart");


function button() {
    ADDTOCART.appendChild(idforADDcart);

    let deletebutton = document.createElement("button");
    deletebutton.textContent = "DleteItems";
    idforADDcart.appendChild(deletebutton);

    ADDTOCART.appendChild(deletebutton);


    deletebutton.onclick = function() {
        ADDTOCART.removeChild(idforADDcart);
    }

}
*/


// Create An Object Here //

let todoobj = [{
    DivContainerid: "venu",

}];
// local Storage here//

let savebtn = document.getElementById("savebtn");
let Addtocartpage = document.getElementById("ADDTOCART");
savebtn.onclick = function() {
    console.log("savebutton is Clicked");

    localStorage.setItem("todocart", JSON.stringify(todoobj));
}
// getting local Storage for client -server //
function getstortedvalue() {
    let getvalue = localStorage.getItem("todocart");
    let parsevalue = JSON.parse(getvalue);
    if (parsevalue === null) {
        return [];
    } else {
        return parsevalue;
    }
}

// reteview the data for callaing function here //
let retrivevalue = getstortedvalue();





// orderNOw here button  //
let ADDTOCART = document.getElementById("ADDTOCART");
let num = 0;
let counter = 0;

function onDeleteTodo(todoId) {
    let todoElement = document.getElementById(todoId);

    ADDTOCART.removeChild(todoElement);
}


function button1() {
    num++;
    let buttonid = "button" + num;
    let divid = "divcontainer" + num;

    let divcontiner = document.createElement("div");
    divcontiner.id = divid;
    divcontiner.classList.add("divjscontainer");
    ADDTOCART.appendChild(divcontiner);
    // calling form html  here  //
    let name = document.getElementById("menuname");
    let imgcon = document.getElementById("imageidurl");


    let imgcontainer = document.createElement("img");
    imgcontainer.src = imgcon.src;
    imgcontainer.classList.add("imgjs");
    divcontiner.appendChild(imgcontainer);

    let headingname = document.createElement("h1");
    headingname.textContent = name.textContent;
    divcontiner.appendChild(headingname);

    let div2 = document.createElement("div");
    div2.classList.add("d-flex", "flex-row");
    divcontiner.appendChild(div2);

    let delbutton = document.createElement("button");
    delbutton.id = buttonid;

    delbutton.textContent = "Delete";
    delbutton.classList.add("custom-outline-button");
    div2.appendChild(delbutton);

    delbutton.onclick = function() {
        onDeleteTodo(divid);
    };

    let paybutton = document.createElement("button");
    paybutton.id = buttonid;
    paybutton.textContent = "OrderNow";
    paybutton.classList.add("custom-outline-button");
    div2.appendChild(paybutton);

    //alret  Message  //
    paybutton.onclick = function() {
        alert("Your Order Mark SuccessFully!!!!");

        return;
    }

    // button increase and deserese  here //
    let div3 = document.createElement("div");
    div3.classList.add("d-flex", "flex-row", "custom-outline-button");
    divcontiner.appendChild(div3);

    let decbutton = document.createElement("button");
    decbutton.id = buttonid;
    decbutton.classList.add("decbutton");
    decbutton.textContent = "Dec";
    decbutton.style.backgroundColor = 'green';
    decbutton.style.color = "white";

    div3.appendChild(decbutton);


    let counters = document.createElement("h1");
    counters.textContent = counter;
    div3.appendChild(counters);

    let incbutton = document.createElement("button");
    incbutton.id = buttonid;
    incbutton.textContent = "Inc";
    incbutton.style.backgroundColor = "Green";
    incbutton.style.color = "white";
    incbutton.classList.add("incbutton");
    div3.appendChild(incbutton);

    let Amount = document.createElement("h1");
    Amount.textContent = "$" + 200 * counter;
    div2.appendChild(Amount);

    incbutton.onclick = function() {
        counter++
        counters.textContent = counter;
        Amount.textContent = "$" + 200 * counter;
        counters.style.color = "green";
        Amount.style.color = "green";
        if (counter === 0) {
            counters.style.color = "Black";
        }
    }


    // new TodoElemet adding here//
    let newTodo = {
        DivContainerid: divid

    };
    console.log(todoobj);
    todoobj.push(newTodo);

    decbutton.onclick = function() {
        if (counter > 0) {
            counter--;
            counters.textContent = counter;
            Amount.textContent = "$" + 200 * counter;
            counters.style.color = "white";
            Amount.style.color = "red";
        } else if (counter === 0) {
            counters.style.color = "Black";
        }
    }
}

let localget = localStorage.getItem("todocart");
Addtocartpage.value = localget;




/// feedback locastorage here  //
let savebutton = document.getElementById("saveBtn");
let clearbutton = document.getElementById("clearBtn");
let textsms = document.getElementById("msg");



savebutton.onclick = function() {
    let textinputvalue = textsms.value;
    let locset = localStorage.setItem("userInput", textinputvalue);
}
clearbutton.onclick = function() {

    textsms.value = "";
    localStorage.removeItem("userInput");
}
let locget = localStorage.getItem("userInput");
textsms.textContent = locget;
// or we can use here""""textsms.value=locget""""also possible is working //

//completed her llocal stoareg here of Feedback//


// here ChatBot  Area js//
let chatbotMsgList = ["Hi How Are You MR!!", "Hey How can I help you?", "Our Team on Progress", "please Wait Some Time!!!!", "we will Back with you Call (or) Email", "Thank You!!!"];


let userInput = document.getElementById("userInput");
let sendMsgBtn = document.getElementById("sendMsgBtn");
let chatplace = document.getElementById("chatContainer");

let count = 0;


sendMsgBtn.onclick = function() {
    let userinputvalue = userInput.value;
    if (userinputvalue === "") {
        alert("Enter VAlue there");
        return;
    }



    let personcontainer = document.createElement("div");
    personcontainer.textContent = userinputvalue;
    personcontainer.classList.add("msg-to-chatbot-container", "msg-to-chatbot");
    chatplace.appendChild(personcontainer);

    let botconatiner = document.createElement("div");
    botconatiner.classList.add("msg-from-chatbot-container", "msg-from-chatbot");
    botconatiner.textContent = chatbotMsgList[count];
    count = count + 1;
    chatplace.appendChild(botconatiner);


    userInput.value = "";
}

// completed ChatBot Area//


// here scheduler time will be starteed//
let divcounter = document.getElementById("countervaluesss");
let timeStart = document.getElementById("startbutton");
let StopButton = document.getElementById("StopButton");
let uniqueid;

timeStart.onclick = function() {
    let counter = 0;

    function countvalue() {

        divcounter.textContent = counter;
        counter = counter + 1;
    }
    uniqueid = setInterval(countvalue, 1000);

    // we can use to Stop the count also we ..//
    StopButton.onclick = function() {
        clearInterval(uniqueid);
    }

};



//here Wikepidie serach results  here///
let searchInputEl = document.getElementById("searchInput");

let searchResultsEl = document.getElementById("searchResults");

let spinnerEl = document.getElementById("spinner");

function createAndAppendSearchResult(result) {
    let {
        link,
        title,
        description
    } = result;

    let resultItemEl = document.createElement("div");
    resultItemEl.classList.add("result-item");

    let titleEl = document.createElement("a");
    titleEl.href = link;
    titleEl.target = "_blank";
    titleEl.textContent = title;
    titleEl.classList.add("result-title");
    resultItemEl.appendChild(titleEl);

    let titleBreakEl = document.createElement("br");
    resultItemEl.appendChild(titleBreakEl);

    let urlEl = document.createElement("a");
    urlEl.classList.add("result-url");
    urlEl.href = link;
    urlEl.target = "_blank";
    urlEl.textContent = link;
    resultItemEl.appendChild(urlEl);

    let linkBreakEl = document.createElement("br");
    resultItemEl.appendChild(linkBreakEl);

    let descriptionEl = document.createElement("p");
    descriptionEl.classList.add("link-description");
    descriptionEl.textContent = description;
    resultItemEl.appendChild(descriptionEl);

    searchResultsEl.appendChild(resultItemEl);
}

function displayResults(searchResults) {
    spinnerEl.classList.add("d-none");

    for (let result of searchResults) {
        createAndAppendSearchResult(result);
    }
}

function searchWikipedia(event) {
    if (event.key === "Enter") {

        spinnerEl.classList.remove("d-none");
        searchResultsEl.textContent = "";

        let searchInput = searchInputEl.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
        let options = {
            method: "GET"
        };

        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResults(search_results);
            });
    }
}

searchInputEl.addEventListener("keydown", searchWikipedia);




// here onWards SignUp Button Http Request method:"POST"    ///




let nameEl = document.getElementById("name");
let nameErrMsgEl = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");

let workingStatusEl = document.getElementById("status");
let genderMaleEl = document.getElementById("genderMale");
let genderFemaleEl = document.getElementById("genderFemale");

let myFormEl = document.getElementById("myForm");

let formData = {
    name: "",
    email: "",
    status: "Active",
    gender: "Male"
};

nameEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        nameErrMsgEl.textContent = "Required*";
    } else {
        nameErrMsgEl.textContent = "";
    }

    formData.name = event.target.value;
});

emailEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        emailErrMsgEl.textContent = "Required*";
    } else {
        emailErrMsgEl.textContent = "";
    }

    formData.email = event.target.value;
});

workingStatusEl.addEventListener("change", function(event) {
    formData.status = event.target.value;
});

genderMaleEl.addEventListener("change", function(event) {
    formData.gender = event.target.value;
});

genderFemaleEl.addEventListener("change", function(event) {
    formData.gender = event.target.value;
});

function validateFormData(formData) {
    let {
        name,
        email
    } = formData;
    if (name === "") {
        nameErrMsgEl.textContent = "Required*";
    }
    if (email === "") {
        emailErrMsgEl.textContent = "Required*";
    }
}

function submitFormData(formData) {
    let options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 00f3f8fde06120db02b587cc372c3d85510896e899b45774068bb750462acd9f",
        },
        body: JSON.stringify(formData)
    };

    let url = "https://gorest.co.in/public-api/users";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);
            if (jsonData.code === 422) {
                if (jsonData.data[0].message === "has already been taken") {
                    emailErrMsgEl.textContent = "Email Already Exists";
                }
            }
        });
}

myFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    validateFormData(formData);
    submitFormData(formData);
});